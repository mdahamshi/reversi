# reversi
AI homework Reversi 12x12
