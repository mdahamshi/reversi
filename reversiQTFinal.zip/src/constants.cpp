#include "constants.h"
Constants* Constants::m_Instance = NULL;
Constants::Constants(QObject *parent) : QObject(parent)
{


}
