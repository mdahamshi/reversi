/****************************************************************************
** Meta object code from reading C++ file 'broker.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../reversiQT/broker.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'broker.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Broker_t {
    QByteArrayData data[30];
    char stringdata0[288];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Broker_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Broker_t qt_meta_stringdata_Broker = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Broker"
QT_MOC_LITERAL(1, 7, 11), // "updateBoard"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 7), // "gameEnd"
QT_MOC_LITERAL(4, 28, 10), // "pcThinking"
QT_MOC_LITERAL(5, 39, 8), // "yourTurn"
QT_MOC_LITERAL(6, 48, 10), // "noPossible"
QT_MOC_LITERAL(7, 59, 6), // "pcPass"
QT_MOC_LITERAL(8, 66, 9), // "gameStart"
QT_MOC_LITERAL(9, 76, 11), // "gameRestart"
QT_MOC_LITERAL(10, 88, 11), // "onGameStart"
QT_MOC_LITERAL(11, 100, 8), // "getColor"
QT_MOC_LITERAL(12, 109, 10), // "printBoard"
QT_MOC_LITERAL(13, 120, 12), // "getBoardSize"
QT_MOC_LITERAL(14, 133, 13), // "getWhiteCount"
QT_MOC_LITERAL(15, 147, 13), // "getBlackCount"
QT_MOC_LITERAL(16, 161, 8), // "setColor"
QT_MOC_LITERAL(17, 170, 14), // "testConnection"
QT_MOC_LITERAL(18, 185, 8), // "gotInput"
QT_MOC_LITERAL(19, 194, 1), // "i"
QT_MOC_LITERAL(20, 196, 1), // "j"
QT_MOC_LITERAL(21, 198, 10), // "createGame"
QT_MOC_LITERAL(22, 209, 9), // "blacktype"
QT_MOC_LITERAL(23, 219, 9), // "whitetype"
QT_MOC_LITERAL(24, 229, 8), // "blackalg"
QT_MOC_LITERAL(25, 238, 8), // "whitealg"
QT_MOC_LITERAL(26, 247, 8), // "blackdep"
QT_MOC_LITERAL(27, 256, 8), // "whitedep"
QT_MOC_LITERAL(28, 265, 14), // "endCurrentGame"
QT_MOC_LITERAL(29, 280, 7) // "getTurn"

    },
    "Broker\0updateBoard\0\0gameEnd\0pcThinking\0"
    "yourTurn\0noPossible\0pcPass\0gameStart\0"
    "gameRestart\0onGameStart\0getColor\0"
    "printBoard\0getBoardSize\0getWhiteCount\0"
    "getBlackCount\0setColor\0testConnection\0"
    "gotInput\0i\0j\0createGame\0blacktype\0"
    "whitetype\0blackalg\0whitealg\0blackdep\0"
    "whitedep\0endCurrentGame\0getTurn"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Broker[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x06 /* Public */,
       3,    0,  115,    2, 0x06 /* Public */,
       4,    0,  116,    2, 0x06 /* Public */,
       5,    0,  117,    2, 0x06 /* Public */,
       6,    0,  118,    2, 0x06 /* Public */,
       7,    0,  119,    2, 0x06 /* Public */,
       8,    0,  120,    2, 0x06 /* Public */,
       9,    0,  121,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    0,  122,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      11,    2,  123,    2, 0x02 /* Public */,
      12,    0,  128,    2, 0x02 /* Public */,
      13,    0,  129,    2, 0x02 /* Public */,
      14,    0,  130,    2, 0x02 /* Public */,
      15,    0,  131,    2, 0x02 /* Public */,
      16,    3,  132,    2, 0x02 /* Public */,
      17,    0,  139,    2, 0x02 /* Public */,
      18,    2,  140,    2, 0x02 /* Public */,
      21,    6,  145,    2, 0x02 /* Public */,
      28,    0,  158,    2, 0x02 /* Public */,
      29,    0,  159,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

 // methods: parameters
    QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   19,   20,
    QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   22,   23,   24,   25,   26,   27,
    QMetaType::Void,
    QMetaType::Int,

       0        // eod
};

void Broker::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Broker *_t = static_cast<Broker *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateBoard(); break;
        case 1: _t->gameEnd(); break;
        case 2: _t->pcThinking(); break;
        case 3: _t->yourTurn(); break;
        case 4: _t->noPossible(); break;
        case 5: _t->pcPass(); break;
        case 6: _t->gameStart(); break;
        case 7: _t->gameRestart(); break;
        case 8: _t->onGameStart(); break;
        case 9: { int _r = _t->getColor((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 10: _t->printBoard(); break;
        case 11: { int _r = _t->getBoardSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 12: { int _r = _t->getWhiteCount();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 13: { int _r = _t->getBlackCount();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 14: _t->setColor((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 15: _t->testConnection(); break;
        case 16: _t->gotInput((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 17: { bool _r = _t->createGame((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 18: _t->endCurrentGame(); break;
        case 19: { int _r = _t->getTurn();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::updateBoard)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::gameEnd)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::pcThinking)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::yourTurn)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::noPossible)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::pcPass)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::gameStart)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (Broker::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Broker::gameRestart)) {
                *result = 7;
                return;
            }
        }
    }
}

const QMetaObject Broker::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Broker.data,
      qt_meta_data_Broker,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Broker::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Broker::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Broker.stringdata0))
        return static_cast<void*>(const_cast< Broker*>(this));
    return QObject::qt_metacast(_clname);
}

int Broker::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void Broker::updateBoard()
{
    QMetaObject::activate(this, &staticMetaObject, 0, Q_NULLPTR);
}

// SIGNAL 1
void Broker::gameEnd()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void Broker::pcThinking()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void Broker::yourTurn()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void Broker::noPossible()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void Broker::pcPass()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void Broker::gameStart()
{
    QMetaObject::activate(this, &staticMetaObject, 6, Q_NULLPTR);
}

// SIGNAL 7
void Broker::gameRestart()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
