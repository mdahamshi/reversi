/****************************************************************************
** Meta object code from reading C++ file 'constants.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../reversiQT/constants.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'constants.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Constants_t {
    QByteArrayData data[8];
    char stringdata0[63];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Constants_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Constants_t qt_meta_stringdata_Constants = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Constants"
QT_MOC_LITERAL(1, 10, 9), // "rowNumber"
QT_MOC_LITERAL(2, 20, 9), // "colNumber"
QT_MOC_LITERAL(3, 30, 5), // "color"
QT_MOC_LITERAL(4, 36, 5), // "BLANK"
QT_MOC_LITERAL(5, 42, 5), // "WHITE"
QT_MOC_LITERAL(6, 48, 5), // "BLACK"
QT_MOC_LITERAL(7, 54, 8) // "POSSIBLE"

    },
    "Constants\0rowNumber\0colNumber\0color\0"
    "BLANK\0WHITE\0BLACK\0POSSIBLE"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Constants[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       1,   20, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Int, 0x00095001,
       2, QMetaType::Int, 0x00095001,

 // enums: name, flags, count, data
       3, 0x0,    4,   24,

 // enum data: key, value
       4, uint(Constants::BLANK),
       5, uint(Constants::WHITE),
       6, uint(Constants::BLACK),
       7, uint(Constants::POSSIBLE),

       0        // eod
};

void Constants::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        Constants *_t = static_cast<Constants *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->rowNumber(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->colNumber(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject Constants::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Constants.data,
      qt_meta_data_Constants,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *Constants::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Constants::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_Constants.stringdata0))
        return static_cast<void*>(const_cast< Constants*>(this));
    return QObject::qt_metacast(_clname);
}

int Constants::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
   if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
